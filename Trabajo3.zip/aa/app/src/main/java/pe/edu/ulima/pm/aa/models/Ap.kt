package pe.edu.ulima.pm.aa.models

class Ap {
    private lateinit var results : ArrayList<Pokemon>

    fun getResults(): ArrayList<Pokemon>? {
        return results
    }
}